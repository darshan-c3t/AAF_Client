package com.c3t.loginapi.controller;

import com.c3t.loginapi.dto.LoginDto;
import com.c3t.loginapi.dto.TokenResponse;
import com.c3t.loginapi.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value ="/client")
public class LoginController {

    @Autowired
    LoginService loginService;

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public TokenResponse login (@RequestBody LoginDto loginDto) throws Exception {
        return loginService.login(loginDto);
    }

    @RequestMapping(value = "/getApi", method = RequestMethod.POST)
    public void getApi (@RequestBody LoginDto loginDto) throws Exception {
        loginService.getApi();
    }

    @RequestMapping(value = "/writeApi", method = RequestMethod.POST)
    public void writeApi (@RequestBody LoginDto loginDto) throws Exception {
        loginService.writeApi();
    }

}
