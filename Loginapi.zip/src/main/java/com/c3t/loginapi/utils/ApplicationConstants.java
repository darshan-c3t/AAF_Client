package com.c3t.loginapi.utils;

public class ApplicationConstants {

    public static final String AUTHORIZATION = "authorization";
}
