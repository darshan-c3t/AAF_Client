package com.c3t.loginapi.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@JsonDeserialize(
        builder = RestResponse.RestResponseBuilder.class
)
public class RestResponse {
    public static final boolean RESPONSE_FAILURE = false;
    public static final boolean RESPONSE_SUCCESS = true;
    public static final String SUCCESS_STATUS = "success";
    public static final String FAILURE_STATUS = "failure";
    public static final String API_V_REGEX = ".?/api/v\\d{1,}/.";
    public static final RestResponse.EmptyJsonResponse EMPY_JSON_OBJECT = new RestResponse.EmptyJsonResponse();
    private static final String MSG_OPERATION_SUCCEEDED = "Operation succeeded!";
    private Object data;
    private Boolean success;
    private List<RestResponse.Message> messages;

    public static RestResponse successBuild(Object data) {
        return builder().data(data).success(true).messages(Arrays.asList(RestResponse.Message.build("Operation succeeded!", "success"))).build();
    }

    public static RestResponse successBuild(Object data, String message) {
        return builder().data(data).success(true).messages(Arrays.asList(RestResponse.Message.build(message, "success"))).build();
    }

    public static RestResponse successBuild(String message) {
        return builder().data(EMPY_JSON_OBJECT).success(true).messages(Arrays.asList(RestResponse.Message.build(message, "success"))).build();
    }

    public static RestResponse failureBuild(Class exceptionClass, String message) {
        return builder().data(EMPY_JSON_OBJECT).success(false).messages(Arrays.asList(RestResponse.Message.build(exceptionClass, message))).build();
    }

    public static RestResponse failureBuild(String message) {
        return builder().data(EMPY_JSON_OBJECT).success(false).messages(Arrays.asList(RestResponse.Message.build(message, "failure"))).build();
    }

    public static RestResponse failureBuild(List<RestResponse.Message> messages) {
        return builder().data(EMPY_JSON_OBJECT).success(false).messages(messages).build();
    }

    public static RestResponse build(Object data, boolean success, List<RestResponse.Message> messages) {
        return builder().data(data).success(success).messages(messages).build();
    }

    RestResponse(Object data, Boolean success, List<RestResponse.Message> messages) {
        this.data = data;
        this.success = success;
        this.messages = messages;
    }

    public static RestResponse.RestResponseBuilder builder() {
        return new RestResponse.RestResponseBuilder();
    }

    public Object getData() {
        return this.data;
    }

    public Boolean getSuccess() {
        return this.success;
    }

    public List<RestResponse.Message> getMessages() {
        return this.messages;
    }

    @JsonDeserialize
    @JsonSerialize
    public static class EmptyJsonResponse {
        public EmptyJsonResponse() {
        }
    }

    @JsonPOJOBuilder(
            withPrefix = ""
    )
    public static class RestResponseBuilder {
        private Object data;
        private Boolean success;
        private List<RestResponse.Message> messages;

        RestResponseBuilder() {
        }

        public RestResponse.RestResponseBuilder data(Object data) {
            this.data = data;
            return this;
        }

        public RestResponse.RestResponseBuilder success(Boolean success) {
            this.success = success;
            return this;
        }

        public RestResponse.RestResponseBuilder messages(List<RestResponse.Message> messages) {
            this.messages = messages;
            return this;
        }

        public RestResponse build() {
            return new RestResponse(this.data, this.success, this.messages);
        }

        public String toString() {
            return "RestResponse.RestResponseBuilder(data=" + this.data + ", success=" + this.success + ", messages=" + this.messages + ")";
        }
    }

    @JsonDeserialize(
            builder = RestResponse.Message.MessageBuilder.class
    )
    public static class Message {
        private String exception;
        private String message;
        private String status;
        private String requestedUri;
        private String timestamp;
        private static final DateTimeFormatter DATE_TIME_FORMATTER = (new DateTimeFormatterBuilder()).appendPattern("yyyy-MM-dd HH:mm:ss").toFormatter();

        public static RestResponse.Message build(Class exceptionClass, String message) {
            return builder().exception(exceptionClass.getName()).message(message).status("failure").requestedUri(extractRequestedUri()).timestamp(LocalDateTime.now().format(DATE_TIME_FORMATTER)).build();
        }

        public static RestResponse.Message build(String message, String status) {
            return builder().message(message).status(status).requestedUri(extractRequestedUri()).timestamp(LocalDateTime.now().format(DATE_TIME_FORMATTER)).build();
        }

        public static RestResponse.Message build(String message, String status, String requestURI) {
            return builder().message(message).status(status).requestedUri(requestURI).timestamp(LocalDateTime.now().format(DATE_TIME_FORMATTER)).build();
        }

        public static RestResponse.Message build(Class exceptionClass, String message, String status, String requestURI) {
            return builder().exception(exceptionClass.getName()).message(message).status(status).requestedUri(requestURI).timestamp(LocalDateTime.now().format(DATE_TIME_FORMATTER)).build();
        }

        private static String extractRequestedUri() {
            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
            if (requestAttributes instanceof ServletRequestAttributes) {
                HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
                return request.getRequestURI();
            } else {
                return "";
            }
        }

        Message(String exception, String message, String status, String requestedUri, String timestamp) {
            this.exception = exception;
            this.message = message;
            this.status = status;
            this.requestedUri = requestedUri;
            this.timestamp = timestamp;
        }

        public static RestResponse.Message.MessageBuilder builder() {
            return new RestResponse.Message.MessageBuilder();
        }

        public String getException() {
            return this.exception;
        }

        public String getMessage() {
            return this.message;
        }

        public String getStatus() {
            return this.status;
        }

        public String getRequestedUri() {
            return this.requestedUri;
        }

        public String getTimestamp() {
            return this.timestamp;
        }

        @JsonPOJOBuilder(
                withPrefix = ""
        )
        public static class MessageBuilder {
            private String exception;
            private String message;
            private String status;
            private String requestedUri;
            private String timestamp;

            MessageBuilder() {
            }

            public RestResponse.Message.MessageBuilder exception(String exception) {
                this.exception = exception;
                return this;
            }

            public RestResponse.Message.MessageBuilder message(String message) {
                this.message = message;
                return this;
            }

            public RestResponse.Message.MessageBuilder status(String status) {
                this.status = status;
                return this;
            }

            public RestResponse.Message.MessageBuilder requestedUri(String requestedUri) {
                this.requestedUri = requestedUri;
                return this;
            }

            public RestResponse.Message.MessageBuilder timestamp(String timestamp) {
                this.timestamp = timestamp;
                return this;
            }

            public RestResponse.Message build() {
                return new RestResponse.Message(this.exception, this.message, this.status, this.requestedUri, this.timestamp);
            }

            public String toString() {
                return "RestResponse.Message.MessageBuilder(exception=" + this.exception + ", message=" + this.message + ", status=" + this.status + ", requestedUri=" + this.requestedUri + ", timestamp=" + this.timestamp + ")";
            }
        }
    }
}