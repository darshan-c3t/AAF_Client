package com.c3t.loginapi.service;

import com.c3t.loginapi.dto.LoginDto;
import com.c3t.loginapi.dto.TokenResponse;
import com.c3t.loginapi.dto.TokenUserResponse;
import com.c3t.loginapi.dto.TokenVerifyRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class AuthService {

    @Value("${client.username}")
    private String clientName;

    @Value("${client.password}")
    private String clientPassword;

    @Value("${auth.tool.url}")
    private String authUrl;

    private final String VERIFY_URL = "/verify";
    private final String LOGIN_URL = "/login";

    @Autowired
    RestTemplate restTemplate;

    public TokenUserResponse verifyToken (String token) throws Exception {
        TokenVerifyRequest tokenVerifyRequest= TokenVerifyRequest.builder().token(token).build();
        HttpEntity<TokenVerifyRequest> request = new HttpEntity<>(tokenVerifyRequest);
        ResponseEntity<TokenUserResponse> response = restTemplate.exchange(authUrl + VERIFY_URL, HttpMethod.POST, request, TokenUserResponse.class);
        if(!StringUtils.equalsAnyIgnoreCase(response.getStatusCode().toString(), HttpStatus.OK.toString())) {
            throw new Exception("Unauthorized");
        }
        return response.getBody();
    }

    public TokenResponse loginUser (String userName, String password) throws Exception {
        LoginDto loginObj = LoginDto.builder().username(userName).password(password).build();

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpHeaders.AUTHORIZATION, createBaseAuth());

        HttpEntity<LoginDto> request = new HttpEntity<>(loginObj, headers);

        ResponseEntity<TokenResponse> response = restTemplate.exchange(authUrl + LOGIN_URL, HttpMethod.POST, request, TokenResponse.class);
        if(!StringUtils.equalsAnyIgnoreCase(response.getStatusCode().toString(), HttpStatus.OK.toString())) {
            throw new Exception("Unauthorized");
        }
        return response.getBody();
    }

    public String createBaseAuth () {
        String plainCreds = clientName + ":" + clientPassword;
        return "basic " + Base64.getEncoder().encodeToString(plainCreds.getBytes());
    }

    public String getValueFromHeader(HttpServletRequest httpRequest, String key) {
        Stream var10000 = Collections.list(httpRequest.getHeaderNames()).stream();
        Function var10001 = (h) -> {
            return h;
        };
        httpRequest.getClass();
        Map<String, String> headers = (Map)var10000.collect(Collectors.toMap(var10001, httpRequest::getHeader));
        return (String)headers.get(key);
    }
}
