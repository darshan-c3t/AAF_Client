package com.c3t.loginapi.utils;

public class ApplicationConstants {

    public static final String AUTHORIZATION = "authorization";
    public static final String ROLE_AUTH = "ROLE_";
}
